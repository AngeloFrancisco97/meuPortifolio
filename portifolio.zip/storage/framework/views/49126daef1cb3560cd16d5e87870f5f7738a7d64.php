

<?php $__env->startSection('content'); ?>
 <inicio-component portifolio="<?php echo e(route('portifolio')); ?>"></inicio-component>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\angel\Desktop\meuSite\portifolio\resources\views/app/inicio.blade.php ENDPATH**/ ?>