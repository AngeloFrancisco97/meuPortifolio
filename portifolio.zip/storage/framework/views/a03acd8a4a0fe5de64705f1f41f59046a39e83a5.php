

<?php $__env->startSection('content'); ?>
<menu-vertical-component class=""></menu-vertical-component>
<?php echo $__env->make('layouts.menuVertical', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<perfil-component class="background-maneiro"></perfil-component>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\angel\Desktop\meuSite\portifolio\resources\views/app/perfil.blade.php ENDPATH**/ ?>