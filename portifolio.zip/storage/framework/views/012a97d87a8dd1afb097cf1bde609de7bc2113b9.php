<?php $__env->startSection('content'); ?>
<menu-vertical-component class=""></menu-vertical-component>
<?php echo $__env->make('layouts.menuVertical', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<home-component projetos="<?php echo e(route('projeto_admin')); ?>" perfil="<?php echo e(route('perfil')); ?>" habilidades="<?php echo e(route('habilidade')); ?>">  
    
</home-component>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\angel\Desktop\meuSite\portifolio\resources\views/home.blade.php ENDPATH**/ ?>