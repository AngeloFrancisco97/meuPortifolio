
<?php /**PATH C:\Users\angel\Desktop\meuSite\portifolio\resources\views/auth/register.blade.php ENDPATH**/ ?>