<?php $__env->startSection('content'); ?>
<background-menu-component class="background-maneiro">
    <h1>Login</h1>
</background-menu-component>
<login-component token_csrf="<?php echo e(@csrf_token()); ?>"></login-component>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\angel\Desktop\meuSite\portifolio\resources\views/auth/login.blade.php ENDPATH**/ ?>