@extends('layouts.app')

@section('content')
<menu-vertical-component class=""></menu-vertical-component>
@include('layouts.menuVertical')
<perfil-component class="background-maneiro"></perfil-component>
@endsection
