@extends('layouts.app')

@section('content')
 <portifolio-component></portifolio-component>
@endsection
