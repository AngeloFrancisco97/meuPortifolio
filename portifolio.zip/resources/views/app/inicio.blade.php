@extends('layouts.app')

@section('content')
 <inicio-component portifolio="{{ route('portifolio')}}"></inicio-component>
@endsection
