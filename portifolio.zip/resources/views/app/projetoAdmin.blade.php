@extends('layouts.app')

@section('content')
<menu-vertical-component class=""></menu-vertical-component>
@include('layouts.menuVertical')
<projeto-admin-component class="background-maneiro">  
</projeto-admin-component>
@endsection
