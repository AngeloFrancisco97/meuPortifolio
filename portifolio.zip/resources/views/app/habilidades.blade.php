@extends('layouts.app')

@section('content')
<menu-vertical-component class=""></menu-vertical-component>
@include('layouts.menuVertical')
<habilidade-component></habilidade-component>
@endsection
