<template>
    

</template>

<script>
export default {

}
</script>

<style>
    .vertical-nav {
    min-width: 17rem;
    width: 17rem;
    height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    box-shadow: 3px 3px 10px rgba(0, 0, 0, 0.1);
    transition: all 0.4s;
    }

    .page-content {
    width: calc(100% - 17rem);
    margin-left: 17rem;
    transition: all 0.4s;
    }

    /* for toggle behavior */

    #sidebar.active {
    margin-left: -17rem;
    }

    #content.active {
    width: 100%;
    margin: 0;
    }

    @media (max-width: 768px) {
    #sidebar {
        margin-left: -17rem;
    }
    #sidebar.active {
        margin-left: 0;
    }
    #content {
        width: 100%;
        margin: 0;
    }
    #content.active {
        margin-left: 17rem;
        width: calc(100% - 17rem);
    }
    }

    /*
    *
    * ==========================================
    * FOR DEMO PURPOSE
    * ==========================================
    *
    */

    

    .separator {
    margin: 3rem 0;
    border-bottom: 1px dashed #fff;
    }

    .text-uppercase {
    letter-spacing: 0.1em;
    }

    .text-gray {
    color: #aaa;
    }
</style>